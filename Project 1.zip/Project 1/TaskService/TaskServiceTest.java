package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import TaskService.Task;
import TaskService.TaskService;

class TaskServiceTest {

	private TaskService service;
	private Task task;
	
	@BeforeEach
	public void initialSetup() {
		service = new TaskService();
		task = new Task("12345", "Task 1", "Description");
	}
	
	//validate adding a test worked
	@Test
	public void testAddTask() {
		boolean result = service.addNewTask(task);
		Assertions.assertTrue(result);
		Assertions.assertEquals(task,  service.getTask("12345"));
	}
	
	//validate adding a duplicate test throws error as expected
	@Test
	public void testAddDuplicateTask() {
		service.addNewTask(task);
		Task duplicateTask = new Task("12345", "Other Task", "Other Description");
		boolean result = service.addNewTask(duplicateTask);
		Assertions.assertFalse(result);
	}
	
	//validate deleting a test worked
	@Test
	public void testDelTask() {
		service.addNewTask(task);
		boolean result = service.deleteaTask("12345");
		Assertions.assertTrue(result);
	}
		
	//validate deleting a task that doesn't exist throws error as expected
	@Test
	public void testDelNonexistentTask() {
		service.addNewTask(task);
		boolean result = service.deleteaTask("does not exist");
		Assertions.assertFalse(result);
	}
	
	//validate updating a name works as expected
	@Test
	public void testAddName() {
		service.addNewTask(task);
		boolean result = service.updateTaskName("12345", "New Name");
		Assertions.assertTrue(result);
		Assertions.assertEquals("New Name", service.getTask("12345").getName());
	}
	
	//validate a null name update throws error as expected
	@Test
	public void testAddNullName() {
		service.addNewTask(task);
		Assertions.assertFalse(service.updateTaskName("12345", null));
	}

	//validate updating a description works as expected
	@Test
	public void testAddDescription() {
		service.addNewTask(task);
		boolean result = service.updateTaskDescription("12345", "New Description");
		Assertions.assertTrue(result);
		Assertions.assertEquals("New Description", service.getTask("12345").getDescription());
	}
	
	//validate a null name update throws error as expected
	@Test
	public void testAddNullDescription() {
		service.addNewTask(task);
		Assertions.assertFalse(service.updateTaskDescription("12345", null));
	}

}
