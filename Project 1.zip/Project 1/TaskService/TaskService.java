package TaskService;

import java.util.HashMap;
import java.util.Map;

public class TaskService {

	//build Map to store tasks
	private Map<String, Task> taskMap;
	
	public TaskService() {
		this.taskMap = new HashMap<>();
	}
	
	//create a new task
	public boolean addNewTask(Task newTask) {
		//validate new task is not null, and that new task ID does not already exist
		if (newTask == null || taskMap.containsKey(newTask.getID())) {
			return false;
		}
		taskMap.put(newTask.getID(), newTask);
		return true;
	}
	
	//delete a  task
	public boolean deleteaTask(String delID) {
		//validate ID exists in our task Map, then delete if so
		if (taskMap.containsKey(delID)) {
			taskMap.remove(delID);
			return true;
		}
		//return false if ID doesn't exist in Map
		return false;
	}
	
	//update task name
	public boolean updateTaskName(String taskID, String newName) {
		Task desiredTask = taskMap.get(taskID);
		if (desiredTask != null && newName != null) {
			desiredTask.setName(newName);
			return true;
		}
		return false;
	}
	
	//update task description
	public boolean updateTaskDescription(String taskID, String newDescription) {
		Task desiredTask = taskMap.get(taskID);
		if (desiredTask != null && newDescription != null) {
			desiredTask.setDescription(newDescription);
			return true;
		}
		return false;
	}
	
	//return task for Test File
	public Task getTask(String taskID) {
		return taskMap.get(taskID);
	}
}
