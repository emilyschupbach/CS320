package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import TaskService.Task;

class TaskTest {

	//test task creation works as expected
	@Test
	void testTaskCreation() {
		Task testTask = new Task("12345", "Task 1", "Task 1 is to finish your coding assignment.");
		assertTrue(testTask.getID().equals("12345"));
		assertTrue(testTask.getName().equals("Task 1"));
		assertTrue(testTask.getDescription().equals("Task 1 is to finish your coding assignment."));
	}
	
	//test nullID throws error
	@Test
	void testTaskIDNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task(null, "Task 1", "Description");
		});
	}
	
	//test nullName throws error
	@Test
	void testTaskNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345", null, "Description");
		});
	}
	
	//test nullDescription throws error
	@Test
	void testTaskDescriptionNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345", "Task 2", null);
		});
	}
	
	//test ID too long
	@Test
	void testTaskIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345678910", "Task 1", "Description");
		});
	}
	
	//test name too long
	@Test
	void testTaskNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345", "Task Name is definitely too long", "Description");
		});
	}
	
	//test description too long
	@Test
	void testTaskDescriptionTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345", "Task 1", "Description is for sure definitely 100% way too long to be accepted");
		});
	}

}
