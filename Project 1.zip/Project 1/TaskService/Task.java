package TaskService;

public class Task {

	private String taskID;
	private String taskName;
	private String taskDescription;
	
	public Task(String id, String name, String description) {
		// validate id input
		if(id == null || id.length() > 10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		
		//validate name input
		if(name == null || name.length() > 20) {
			throw new IllegalArgumentException("Invalid name");
		}
		
		//validate description input
		if(description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid description");
		}
		
		this.taskName = name;
		this.taskID = id;
		this.taskDescription = description;
	}
	
	//Getters
	public String getID() {
		return taskID;
	}
	
	public String getName() {
		return taskName;
	}
	
	public String getDescription() {
		return taskDescription;
	}
	
	//Setters
	public void setName(String newName) {
		this.taskName = newName;
	}
	
	public void setDescription(String newDescription) {
		this.taskDescription = newDescription;
	}
}
