package contact;

public class Contact {
	private String contactID;
	private String firstName;
	private String lastName;
	private String Number;
	private String Address;
	
	public Contact(String contactID, String firstName, String lastName, String Number, String Address) {
		if(contactID == null || contactID.length()>10) {
			throw new IllegalArgumentException("Invalid Contact ID");
		}
		if(firstName == null || firstName.length()>10) {
			throw new IllegalArgumentException("Invalid First Name");
		}
		if(lastName == null || lastName.length()>10) {
			throw new IllegalArgumentException("Invalid Last Name");
		}
		if(Number == null |  Number.length()!=10) {
			throw new IllegalArgumentException("Invalid Number");
		}
		if(Address == null || Address.length()>30) {
			throw new IllegalArgumentException("Invalid Address");
		}
		
		this.contactID = contactID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.Number = Number;
		this.Address = Address;
	}
	
	// getters
	public String getID() {
		return contactID;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public String getNumber() {
		return Number;
	}
	
	public String getAddress() {
		return Address;
	}
	
	//setters
	public void setFirstName(String firstName) {
		if (firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid new first name");
		}
		this.firstName = firstName;
	}
	
	public void setLastName(String lasstName) {
		if (lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid new last name");
		}
		this.lastName = lastName;
	}
	
	public void setNumber(String newNumber) {
		if (newNumber == null || newNumber.length() != 10) {
			throw new IllegalArgumentException("Invalid new number");
		}
		this.Number = newNumber;
	}
	
	public void setAddress(String newAddress) {
		if (newAddress == null || newAddress.length() > 30) {
			throw new IllegalArgumentException("Invalid new address");
		}
		this.Address = newAddress;
	}
		
}
