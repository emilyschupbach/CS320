package contact;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
	private final Map<String, Contact> contacts = new HashMap<>();
	
	
	public void addContact(Contact newContact) {
		if(contacts.containsKey(newContact.getID())) {
			throw new IllegalArgumentException("Error: Contact ID already exists");
		}
		contacts.put(newContact.getID(), newContact);
	}
	
	public void deleteContact(String deleteID) {
		if(!contacts.containsKey(deleteID)) {
			throw new IllegalArgumentException("Error: ID does not exist");
		}
		contacts.remove(deleteID);
	}
	
	public void updateFirstName(String contactID, String newFirstName) {
		Contact contact = getContact(contactID);
		contact.setFirstName(newFirstName);
	}
	
	public void updateLastName(String contactID, String newLastName) {
		Contact contact = getContact(contactID);
		contact.setLastName(newLastName);
	}
	
	public void updateNumber(String contactID, String newNumber) {
		Contact contact = getContact(contactID);
		contact.setNumber(newNumber);
	}
	
	public void updateAddress(String contactID, String newAddress) {
		Contact contact = getContact(contactID);
		contact.setAddress(newAddress);
	}
	
	//helper function to get Contact
	private Contact getContact(String contactID) {
		Contact contact = contacts.get(contactID);
		if (contact == null) {
			throw new IllegalArgumentException("Error: could not find Contact ID");
		}
		return contact;
	}
	
	//helper function for testing - return contact ID
	public Contact getContactInfo(String desiredID) {
		return getContact(desiredID);
	}
}
