package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ContactServiceTest {
	
	private ContactService service;
	private Contact contact;
	
	@BeforeEach
	public void initialSetup() {
		service = new ContactService();
		contact = new Contact("1234567", "Emily", "Schupbach", "2021234567", "123 SNHU Street");
		service.addContact(contact);
	}

	// Test Add new Contact builds as expected
		@Test
		public void testNewContact() {
			Contact testNewContact = new Contact("1234568", "Emily", "Schupbach", "2021234567", "123 SNHU Street");
			service.addContact(testNewContact);
			assertTrue(service.getContactInfo("1234568").getFirstName().equals("Emily"));
		}
		
	// Test Delete Contact executes as expected
		@Test
		public void testDeleteContact() {
			service.deleteContact("1234567");
			assertThrows(IllegalArgumentException.class, () -> service.getContactInfo("1234567"));
		}

	// Test Info Updates
		@Test
		public void testUpdateFirstName() {
			service.updateFirstName("1234567", "John");
			assertEquals("John", service.getContactInfo("1234567").getFirstName());
		}
		
		@Test
		public void testUpdateLastName() {
			service.updateLastName("1234567", "Doe");
			assertEquals("Doe", service.getContactInfo("1234567").getLastName());
		}
		
		@Test
		public void testUpdateNumber() {
			service.updateFirstName("1234567", "7031234567");
			assertEquals("7031234567", service.getContactInfo("1234567").getNumber());
		}
		
		@Test
		public void testUpdateAddress() {
			service.updateAddress("1234567", "456 SNHU Street");
			assertEquals("456 SNHU Street", service.getContactInfo("1234567").getAddress());
		}
		
	private void assertTrue(boolean equals) {
		// TODO Auto-generated method stub
		
	}

}
