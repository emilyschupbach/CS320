package contact;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;


class ContactTest {
	
	/** Contact Creation assigns attributes as expected*/
	@Test
	void testContact() {
		Contact testContact = new Contact("1234567", "Emily", "Schupbach", "2021234567", "123 SNHU Street");
			assertTrue(testContact.getID().equals("1234567"));
			assertTrue(testContact.getFirstName().equals("Emily"));
		    assertTrue(testContact.getLastName().equals("Schupbach"));
		    assertTrue(testContact.getNumber().equals("2021234567"));
		    assertTrue(testContact.getAddress().equals("123 SNHU Street"));
	}
	
	
	/** Test input lengths throw errors as expected*/
	@Test
	void testContactIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910", "Emily", "Schupbach","2021234567", "123 SNHU Street");
			
		});
	}
	
	@Test
	void testContactFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567", "Emilyyyyyyy", "Schupbach","2021234567", "123 SNHU Street");
			
		});
	}
	
	@Test
	void testContactLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567", "Emily", "Schupbachhhh","2021234567", "123 SNHU Street");
			
		});
	}
	
	@Test
	void testContactNumberTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567", "Emily", "Schupbach","20212345678910", "123 SNHU Street");
			
		});
	}
	
	@Test
	void testContactAddress() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567", "Emily", "Schupbach","2021234567", "1234567 SNHU Street Washington, DC, 12345");
			
		});
	}
	

	/** Test null inputs  throw errors as expected*/
	@Test
	void testContactIDNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "Emily", "Schupbach","2021234567", "123 SNHU Street");
			
		});
	}
	
	@Test
	void testContactFirstNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567", null, "Schupbach","2021234567", "123 SNHU Street");
			
		});
	}
	
	@Test
	void testContactLastNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567", "Emily", null,"2021234567", "123 SNHU Street");
			
		});
	}
	
	@Test
	void testContactNumberNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567", "Emily", "Schupbach",null, "123 SNHU Street");
			
		});
	}
	
	@Test
	void testContactAddressNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567", "Emily", "Schupbach","2021234567", null);
			
		});
	}
	
	@Test
	void testSetLastName() {
		Contact contact = new Contact("1234567", "Emily", "Schupbach","2021234567", "123 SNHU Street");
		contact.setLastName("Smith");
		assertTrue(contact.getLastName().equals("Smith"));
		;
	}
	
	@Test
	void testSetFirstName() {
		Contact contact = new Contact("1234567", "Emily", "Schupbach","2021234567", "123 SNHU Street");
		contact.setFirstName("Emma");
		assertTrue(contact.getFirstName().equals("Emma"));
		
	}
	
	@Test
	void testSetAddress() {
		Contact contact = new Contact("1234567", "Emily", "Schupbach","2021234567", "123 SNHU Street");
		contact.setAddress("1234 SNHU St");
		assertTrue(contact.getAddress().equals("1234 SNHU St"));
		
	}
	
	
	private void assertTrue(boolean equals) {
		// TODO Auto-generated method stub
		
	}

}
