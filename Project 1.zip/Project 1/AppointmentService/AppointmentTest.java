package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import java.util.Calendar;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import appointment.Appointment;

class AppointmentTest {

	private Date eligibleDate;
	private Date ineligibleDate;
	
	@BeforeEach
    void setup() {
        Calendar calendar = Calendar.getInstance();

        calendar.add(Calendar.DAY_OF_MONTH, 7); // next week
        eligibleDate = calendar.getTime();

        calendar.add(Calendar.DAY_OF_MONTH, -8); // last week
        ineligibleDate = calendar.getTime();
	}
        
	/** Contact Creation assigns attributes as expected*/
	@Test
	void testAppointment() {
		Appointment testAppointment = new Appointment("1234567", eligibleDate, "Appointment details");
		assertTrue(testAppointment.getAppointmentID().equals("1234567"));
		assertTrue(testAppointment.getAppointmentDate().equals(eligibleDate));
		assertTrue(testAppointment.getAppointmentDetails().equals("Appointment details"));
	}
	
	/** Test null inputs  throw errors as expected*/
	@Test
	void testAppointmentIDNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment(null, eligibleDate, "Appointment details");
		});
	}
	
	@Test
	void testAppointmentDateNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567", null, "Appointment details");
		});
	}
	
	@Test
	void testAppointmentDetailsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567", eligibleDate, null);
		});
	}
	/** Test input lengths throw errors as expected*/
	@Test
	void testAppointmentIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("12345678910", eligibleDate, "Appointment details");
		});
	}
	
	@Test
	void testAppointmentDetailsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567", eligibleDate, "Appointment details that are really really really too long.");
		});
	}
	
	@Test
	void testAppointmentDateValid() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567", ineligibleDate, "Appointment details");
		});
	}
	
	@Test
	void testUpdatePastDate() {
		Appointment testAppointment = new Appointment("1234567", eligibleDate, "Appointment details");
		
		assertThrows(IllegalArgumentException.class, () -> {
			testAppointment.setAppointmentDate(ineligibleDate);
		});
	}
	
	@Test
	void canUpdateDate() {
		Appointment testAppointment = new Appointment("1234567", eligibleDate, "Appointment details");
		
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_MONTH, 5);
		Date newDate = calendar.getTime();
		
		testAppointment.setAppointmentDate(newDate);
		assertEquals(newDate,testAppointment.getAppointmentDate());
		};
		
	}


