package appointment;

import java.util.HashMap;
import java.util.Map;


public class AppointmentService {

	private final Map<String, Appointment> appointments = new HashMap<>();
	
	public void addAppointment(Appointment newAppointment) {
		if(appointments.containsKey(newAppointment.getAppointmentID())) {
			throw new IllegalArgumentException("Error: Appointment ID already exists");
		}
		appointments.put(newAppointment.getAppointmentID(), newAppointment);
	}
	
	public boolean deleteAppointment(String appointmentID) {
		if (appointmentID == null) {
			throw new IllegalArgumentException("Error: ID cannot be null");
		}
		return appointments.remove(appointmentID) != null;
	}
	
	public Appointment getAppointment(String desiredID) {
		return appointments.get(desiredID);
				
	}
}
