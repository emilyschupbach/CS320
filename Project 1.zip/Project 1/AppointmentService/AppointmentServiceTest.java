package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import java.util.Calendar;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import appointment.Appointment;
import appointment.AppointmentService;

class AppointmentServiceTest {

	private AppointmentService service;
	private Date eligibleDate;
	
	@BeforeEach
	void setup() {
		service = new AppointmentService();

		Calendar calendar = Calendar.getInstance();
	    calendar.add(Calendar.DAY_OF_MONTH, 7); // date next week
	    eligibleDate = calendar.getTime();
	    
	}
	
	@Test
	void testAddAppointment() {
		Appointment newAppointment = new Appointment("1234567", eligibleDate, "Appointment details");
		service.addAppointment(newAppointment);
	
		assertEquals(newAppointment, service.getAppointment("1234567"));
	}
	
	@Test
	void testDeleteAppointment() {
		Appointment newAppointment = new Appointment("Delete", eligibleDate, "Delete this appointment");
		service.addAppointment(newAppointment);
		
		assertTrue(service.deleteAppointment(newAppointment.getAppointmentID()));
	}

	@Test
	void testnullDeleteAppointment() {
		Appointment newAppointment = new Appointment("Delete", eligibleDate, "Delete this appointment");
		service.addAppointment(newAppointment);
		
		assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment(null));
	}
	
}
