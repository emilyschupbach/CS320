package appointment;

import java.util.Date;

public class Appointment {

	private String appointmentID;
	private Date appointmentDate;
	private String appointmentDetails;
	
	public Appointment(String id, Date date, String details) {
		// validate id input
		if(id == null || id.length() > 10) {
			throw new IllegalArgumentException("Invalid ID");
		}
				
		//validate name input
		if(date == null || date.before(new Date())) {
			throw new IllegalArgumentException("Invalid date");
		}
				
		//validate description input
		if(details == null || details.length() > 50) {
			throw new IllegalArgumentException("Invalid details");
		}
				
		this.appointmentID = id;
		this.appointmentDate = date;
		this.appointmentDetails = details;
	}
	
	//getters
	
	public String getAppointmentID() {
		return appointmentID;
	}
	
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	
	public String getAppointmentDetails() {
		return appointmentDetails;
	}
	
	//setters
	
	public void setAppointmentDate(Date newDate) {
		if(newDate == null || newDate.before(new Date())) {
			throw new IllegalArgumentException("Invalid date");
		}
		this.appointmentDate = newDate;
	}
	
	public void setAppointmentDetails(String newDetails) {
		if(newDetails == null || newDetails.length() > 50) {
			throw new IllegalArgumentException("Invalid details");
		}
		this.appointmentDetails = newDetails;
	}
}
